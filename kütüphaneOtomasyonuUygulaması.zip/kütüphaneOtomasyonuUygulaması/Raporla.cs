﻿using System;
using System.Windows.Forms; 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kütüphaneOtomasyonuUygulaması
{
    public class Raporla
    {
        public void Aktar(int uyeID, TextBox txtUyeID, TextBox txtAd, TextBox txtSoyad, TextBox txtTelefon, TextBox txtMail,
        TextBox txtKitapID, TextBox txtElindekiKitap, TextBox txtOduncTarih, TextBox txtSonTeslimTarih)
        {
            
        }
    }
}
